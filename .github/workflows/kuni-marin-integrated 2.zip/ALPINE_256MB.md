# Alpine, 256 МБ ОЗУ

**Собирать на самом сервере нельзя** (GCC 15 + TDLib + AUI требуют несколько ГБ). Собирай на другой машине, на сервер кладёшь только бинарник.

1. Сборка (на ПК/VPS побольше): `docker build -f Dockerfile.alpine-build -t kuni-alpine-build .`, затем `docker create --name k kuni-alpine-build && docker cp k:/out ./out`.
2. На сервере: `apk add libstdc++ libgcc openssl curl fontconfig freetype libx11 libxcursor libxi libxrandr glew mesa-gl pulseaudio-libs dbus-libs libepoxy` (смотри `out/ldd.txt`, чего не хватает). Это место на диске, не ОЗУ.
3. `./setup_swap_alpine.sh` (root): zram 192 МБ + своп-файл 512 МБ.
4. Скопируй `config.alpine-256mb.example.toml` в `config.toml`, впиши ключи, `chmod 600 config.toml`.
5. `./run_alpine_256mb.sh`, мониторинг: `free -m`, `ps -o rss,cmd`.

## Что изменено
- `misc.tdlib_low_memory = true`: TDLib не ведёт БД файлов/чатов/сообщений.
- Профиль: история чата 20, дневник в промпте 1200, anti-repeat 4, всё тяжёлое (vision, звук, фото, поиск) выключено.
- `MinSizeRel`, `--gc-sections`, strip; тесты и FFmpeg отключены.

## Сборка через GitHub Actions
Залей проект в свой репозиторий на GitHub, вкладка Actions -> «Alpine 256MB build» -> Run workflow. Через ~час в Artifacts будет `kuni-alpine-x86_64` (или `aarch64`). Скачай, положи на сервер рядом со скриптами, `chmod +x kuni`.

## Честно о границах
- Я не мог собрать и запустить проект (нет сети в песочнице), так что **не проверено**, уложится ли он в 256 МБ. Ожидай ~100-200 МБ RSS с TDLib; своп обязателен.
- Дневник целиком кэшируется в ОЗУ, эмбеддинги в `double`. Если записей будут тысячи, нужно будет перевести на `float` или постраничное чтение.
- Исполняемый файл линкуется с `aui::views` (X11/GL), хотя окно нужно только в `--debug`. Это место на диске, не ОЗУ.
- Не запускай `--debug` на сервере.
