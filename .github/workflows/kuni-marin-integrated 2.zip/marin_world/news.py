#!/usr/bin/env python3
"""Сводка новостей. news.py "запрос" [сколько]  |  news.py  (по interests.txt)"""
import os, sys, urllib.parse, urllib.request, xml.etree.ElementTree as ET

DIR = os.path.dirname(os.path.abspath(__file__))


def fetch(q, n):
    url = "https://news.google.com/rss/search?q=" + urllib.parse.quote(q) + "&hl=ru&gl=RU&ceid=RU:ru"
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(req, timeout=15) as r:
        root = ET.fromstring(r.read())
    out = []
    for item in root.iter("item"):
        out.append((item.findtext("title", ""), item.findtext("link", ""), item.findtext("pubDate", "")))
        if len(out) >= n:
            break
    return out


def show(q, n):
    print(f"=== {q}")
    try:
        for t, l, d in fetch(q, n):
            print(f"- {t}\n  {l}")
    except Exception as e:
        print(f"(не удалось получить новости: {e})")


if len(sys.argv) > 1:
    show(sys.argv[1], int(sys.argv[2]) if len(sys.argv) > 2 else 6)
else:
    path = os.path.join(DIR, "interests.txt")
    topics = [l.strip() for l in open(path, encoding="utf-8")] if os.path.exists(path) else ["аниме", "косплей"]
    for t in [x for x in topics if x][:5]:
        show(t, 4)
