#!/usr/bin/env python3
"""Мир Марин v2: две комнаты, время суток, погода, настроение, проект костюма, журнал, энергия.
Управляется командами, состояние в state.json (его показывает index.html)."""
import json, os, random, sys, time

DIR = os.path.dirname(os.path.abspath(__file__))
STATE = os.path.join(DIR, "state.json")
LOG = os.path.join(DIR, "log.txt")
JOURNAL = os.path.join(DIR, "journal.md")

MAPS = {
    "room": [
        "########################",
        "#..WW....P..P....WW...M#",
        "#......................#",
        "#.BB...........TT......#",
        "#.BB...........TT...C..#",
        "#......SSSS...........G#",
        "#......SSSS......R.....#",
        "#......................#",
        "#...F.F.F..........K...#",
        "#......................#",
        "###########DD###########",
    ],
    "balcony": [
        "############",
        "#..F....F..#",
        "#....HH....#",
        "G..........#",
        "#..F.......#",
        "VVVVVVVVVVVV",
    ],
}
ROOM_TITLE = {"room": "своя комната", "balcony": "балкон"}
START = {"room": (11, 9), "balcony": (1, 3)}
WALK = set(".RDG")

OBJ = {
    "B": ("bed", "Кровать с розовым пледом. Тут можно спать (команда sleep)."),
    "W": ("window", None),
    "P": ("poster", "Постер с аниме и косплейными референсами."),
    "M": ("mannequin", "Манекен с недошитым костюмом. Иголка воткнута в рукав."),
    "T": ("sewing", "Швейный стол: ткани, нитки, выкройки. Тут можно шить (команда sew)."),
    "S": ("sofa", "Диван. Можно полежать и ничего не делать."),
    "C": ("computer", "Старый компьютер в углу. Через него видно внешний мир, то есть ноутбук."),
    "R": ("rug", "Пушистый ковёр."),
    "F": ("plant", "Горшок с растением, похоже, живым."),
    "K": ("wardrobe", "Шкаф с косплеями. Тут всего слишком много."),
    "H": ("tea_table", "Столик для чая. Тут приятно сидеть и думать."),
    "V": ("view", None),
    "D": ("door", "Дверь наружу — в ноутбук. Отсюда можно выйти (leave)."),
}
GLOBAL_OBJ_BY_ROOM = {
    ("room", "G"): ("balcony_door", "Дверь на балкон. Можно выйти на воздух (команда go)."),
    ("balcony", "G"): ("room_door", "Дверь обратно в комнату (команда go)."),
}

MOODS = ["спокойная", "весёлая", "вдохновлённая", "мечтательная", "грустная", "раздражённая"]
DAY_EVENTS = [
    ("весёлая", "Утром в окне такое красивое небо, настроение отличное."),
    ("вдохновлённая", "Приснился костюм, который хочется сшить."),
    ("раздражённая", "Нитка запуталась в узел, бесит."),
    ("мечтательная", "Захотелось на фестиваль косплея, листаю фото."),
    ("спокойная", "Тихий день, никуда не нужно торопиться."),
    ("грустная", "Слегка грустно без причины. Бывает."),
]
PROJECTS = ["костюм из любимого аниме", "платье в стиле лолиты", "мини-кимоно", "плащ ведьмы", "школьная форма с аксессуарами"]
STAGES = [(0, "выкройка"), (25, "раскрой"), (50, "сборка"), (75, "отделка")]
WEATHER = {"sunny": "солнечно", "cloudy": "облачно", "rain": "дождь", "snow": "снег", "storm": "гроза", "fog": "туман"}


def now():
    return time.time()


def daypart():
    h = time.localtime().tm_hour
    if 5 <= h < 9:
        return "утро"
    if 9 <= h < 18:
        return "день"
    if 18 <= h < 23:
        return "вечер"
    return "ночь"


def default_state():
    return {"x": 11, "y": 8, "room": "room", "where": "world", "energy": 80, "sleeping": False,
            "updated": now(), "events": [], "mood": "спокойная", "weather": "cloudy",
            "project": {"name": PROJECTS[0], "progress": 0, "done": 0}, "journal": [], "day": ""}


def load():
    if os.path.exists(STATE):
        with open(STATE, encoding="utf-8") as f:
            s = json.load(f)
        for k, v in default_state().items():
            s.setdefault(k, v)
        return s
    return default_state()


def add(s, text):
    s["events"].append({"t": time.strftime("%H:%M:%S"), "text": text})
    s["events"] = s["events"][-25:]
    with open(LOG, "a", encoding="utf-8") as f:
        f.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')} {text}\n")


def tick(s):
    dt_h = max(0.0, (now() - s["updated"]) / 3600.0)
    if s["sleeping"]:
        s["energy"] = min(100, s["energy"] + 25 * dt_h)
        if s["energy"] >= 100:
            s["sleeping"] = False
            add(s, "проснулась, полная сил")
    elif s["where"] == "world":
        s["energy"] = max(0, s["energy"] - 6 * dt_h)
    else:
        s["energy"] = max(0, s["energy"] - 12 * dt_h)
    s["updated"] = now()
    today = time.strftime("%Y-%m-%d")
    if s["day"] != today:
        s["day"] = today
        mood, text = random.choice(DAY_EVENTS)
        s["mood"] = mood
        add(s, "новый день: " + text)


def save(s):
    s["w"], s["h"] = len(MAPS[s["room"]][0]), len(MAPS[s["room"]])
    s["map"] = MAPS[s["room"]]
    s["room_title"] = ROOM_TITLE[s["room"]]
    s["daypart"] = daypart()
    tmp = STATE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(s, f, ensure_ascii=False)
    os.replace(tmp, STATE)


def obj_at(room, ch):
    if (room, ch) in GLOBAL_OBJ_BY_ROOM:
        return GLOBAL_OBJ_BY_ROOM[(room, ch)]
    return OBJ.get(ch)


def near(s):
    out = []
    m = MAPS[s["room"]]
    for dx, dy in ((0, 0), (1, 0), (-1, 0), (0, 1), (0, -1)):
        x, y = s["x"] + dx, s["y"] + dy
        if 0 <= y < len(m) and 0 <= x < len(m[0]):
            o = obj_at(s["room"], m[y][x])
            if o and o[0] not in out:
                out.append(o[0])
    return sorted(out)


def describe_sky(s, kind):
    wx = WEATHER.get(s["weather"], "облачно")
    dp = s["daypart"]
    if kind == "window":
        return f"За окном {dp}, {wx}."
    return f"С балкона виден город. Сейчас {dp}, {wx}."


def mood_now(s):
    return "уставшая" if s["energy"] < 25 else s["mood"]


def status(s):
    e = int(s["energy"])
    place = f"в своём мире ({ROOM_TITLE[s['room']]})" if s["where"] == "world" else "снаружи, в ноутбуке"
    sl = " Ты спишь." if s["sleeping"] else ""
    hint = ""
    if daypart() == "ночь" and not s["sleeping"] and s["where"] == "world":
        hint = " Сейчас ночь, самое время поспать."
    p = s["project"]
    stage = [n for t, n in STAGES if p["progress"] >= t][-1]
    return (f"Ты {place}. Время суток: {daypart()}, погода: {WEATHER.get(s['weather'], '?')}. "
            f"Энергия {e}/100, настроение: {mood_now(s)}.{sl}{hint}\n"
            f"Проект: {p['name']} ({stage}, {p['progress']}%). Готовых костюмов: {p['done']}.")


def render(s):
    if s["where"] != "world":
        return "(ты сейчас снаружи, в ноутбуке; твоя комната пуста)"
    m = MAPS[s["room"]]
    return "\n".join("".join("@" if (x, y) == (s["x"], s["y"]) else ch for x, ch in enumerate(row)) for y, row in enumerate(m))


def targets(s, name):
    m = MAPS[s["room"]]
    res = []
    for y, row in enumerate(m):
        for x, ch in enumerate(row):
            o = obj_at(s["room"], ch)
            if o and o[0] == name:
                res.append((x, y))
    return res


def journal_read(n=5):
    if not os.path.exists(JOURNAL):
        return "Журнал пока пуст."
    with open(JOURNAL, encoding="utf-8") as f:
        text = f.read()
    parts = [p for p in text.split("## ") if p.strip()]
    return "\n".join("## " + p.strip() + "\n" for p in parts[-n:])


def main(argv):
    cmd = argv[1] if len(argv) > 1 else "look"
    arg = argv[2] if len(argv) > 2 else ""
    s = load()
    tick(s)
    msg = ""
    in_world = s["where"] == "world"
    if s["sleeping"] and cmd not in ("look", "status", "wake", "journal"):
        msg = "Ты спишь. Сначала проснись (wake) или дождись утра."
    elif cmd in ("look", "status"):
        pass
    elif cmd == "wake":
        if s["sleeping"]:
            s["sleeping"] = False
            add(s, "проснулась раньше времени")
            msg = "Ты проснулась."
        else:
            msg = "Ты и так не спишь."
    elif cmd == "move":
        if not in_world:
            msg = "Ты не в мире. Вернись командой enter."
        else:
            vec = {"up": (0, -1), "down": (0, 1), "left": (-1, 0), "right": (1, 0)}.get(arg)
            n = int(argv[3]) if len(argv) > 3 and argv[3].isdigit() else 1
            if not vec:
                msg = "Используй: move up|down|left|right [шагов]"
            else:
                m = MAPS[s["room"]]
                moved = 0
                for _ in range(min(n, 30)):
                    nx, ny = s["x"] + vec[0], s["y"] + vec[1]
                    if 0 <= ny < len(m) and 0 <= nx < len(m[0]) and m[ny][nx] in WALK:
                        s["x"], s["y"] = nx, ny
                        moved += 1
                    else:
                        break
                msg = f"Прошла шагов: {moved}." + (" Дальше препятствие." if moved < n else "")
                add(s, f"прошлась ({arg} {moved})")
    elif cmd == "goto":
        names = sorted({o[0] for r in MAPS for row in MAPS[r] for ch in row for o in [obj_at(r, ch)] if o and r == s["room"]})
        if not in_world:
            msg = "Ты не в мире. Вернись командой enter."
        elif arg not in names:
            msg = "Куда: " + ", ".join(names)
        else:
            m = MAPS[s["room"]]
            best = None
            for ox, oy in targets(s, arg):
                for dx, dy in ((0, 1), (0, -1), (1, 0), (-1, 0)):
                    x, y = ox + dx, oy + dy
                    if 0 <= y < len(m) and 0 <= x < len(m[0]) and m[y][x] in WALK:
                        dist = abs(x - s["x"]) + abs(y - s["y"])
                        if best is None or dist < best[0]:
                            best = (dist, x, y)
            if best:
                s["x"], s["y"] = best[1], best[2]
                msg = f"Подошла к объекту: {arg}."
                add(s, f"подошла: {arg}")
            else:
                msg = "Не получилось подойти."
    elif cmd == "interact":
        if not in_world:
            msg = "Ты не в мире."
        elif arg not in near(s):
            msg = f"Рядом нет объекта «{arg}». Рядом: {', '.join(near(s)) or 'ничего'}."
        else:
            if arg in ("window", "view"):
                msg = describe_sky(s, arg)
            else:
                msg = [o[1] for r in MAPS for row in MAPS[r] for ch in row for o in [obj_at(r, ch)] if o and o[0] == arg and o[1]][0]
            add(s, f"взаимодействие: {arg}")
    elif cmd == "go":
        if not in_world:
            msg = "Ты не в мире."
        elif "balcony_door" in near(s) and s["room"] == "room":
            s["room"] = "balcony"
            s["x"], s["y"] = START["balcony"]
            add(s, "вышла на балкон")
            msg = "Ты вышла на балкон."
        elif "room_door" in near(s) and s["room"] == "balcony":
            s["room"] = "room"
            s["x"], s["y"] = 22, 5
            add(s, "вернулась с балкона в комнату")
            msg = "Ты вернулась в комнату."
        else:
            msg = "Подойди к двери на балкон (goto balcony_door) или к двери в комнату (goto room_door)."
    elif cmd == "sleep":
        if not in_world:
            msg = "Спать можно только в своей комнате. Вернись командой enter."
        elif "bed" not in near(s):
            msg = "Сначала подойди к кровати: goto bed."
        elif s["energy"] >= 95:
            msg = "Спать не хочется: ты полна сил."
        else:
            s["sleeping"] = True
            add(s, "легла спать")
            msg = "Ты легла спать. Восстановление примерно 25 энергии в час."
    elif cmd == "sew":
        if not in_world or "sewing" not in near(s):
            msg = "Чтобы шить, подойди к швейному столу: goto sewing."
        elif s["energy"] < 10:
            msg = "Слишком устала, глаза слипаются. Поспи."
        else:
            p = s["project"]
            p["progress"] = min(100, p["progress"] + 8)
            s["energy"] = max(0, s["energy"] - 3)
            if p["progress"] >= 100:
                p["done"] += 1
                add(s, f"закончила проект: {p['name']}")
                msg = f"Готово! Ты закончила: {p['name']}. Всего готовых костюмов: {p['done']}."
                p["name"] = PROJECTS[p["done"] % len(PROJECTS)]
                p["progress"] = 0
                s["mood"] = "вдохновлённая"
            else:
                add(s, f"шила: {p['name']} ({p['progress']}%)")
                msg = f"Ты пошила кусочек. Проект «{p['name']}»: {p['progress']}%."
    elif cmd == "mood":
        if arg in MOODS:
            s["mood"] = arg
            add(s, f"настроение: {arg}")
            msg = f"Настроение теперь: {arg}."
        else:
            msg = "Настроение: " + ", ".join(MOODS)
    elif cmd == "weather":
        if arg in WEATHER:
            s["weather"] = arg
            add(s, f"погода: {WEATHER[arg]}")
            msg = f"Погода за окном теперь: {WEATHER[arg]}."
        else:
            msg = "Погода: " + ", ".join(WEATHER)
    elif cmd == "journal":
        text = " ".join(argv[2:]).strip()
        if not text:
            msg = journal_read()
        else:
            stamp = time.strftime("%Y-%m-%d %H:%M")
            with open(JOURNAL, "a", encoding="utf-8") as f:
                f.write(f"## {stamp}\n{text}\n\n")
            s["journal"].append({"t": stamp, "text": text})
            s["journal"] = s["journal"][-10:]
            add(s, "записала в журнал")
            msg = "Записано в журнал."
    elif cmd == "leave":
        if not in_world:
            msg = "Ты уже снаружи."
        elif s["room"] != "room" or "door" not in near(s):
            msg = "Сначала подойди к двери наружу в комнате: goto door."
        elif s["energy"] < 15:
            msg = "Ты слишком устала, чтобы выходить. Поспи."
        else:
            s["where"] = "laptop"
            add(s, "вышла из мира наружу, в ноутбук")
            msg = "Ты вышла из своего мира наружу. Теперь у тебя есть ноутбук и интернет. Снаружи энергия тратится быстрее."
    elif cmd == "enter":
        if in_world:
            msg = "Ты уже дома."
        else:
            s["where"] = "world"
            s["room"] = "room"
            s["x"], s["y"] = START["room"]
            add(s, "вернулась в свой мир")
            msg = "Ты вернулась в свою комнату. Здесь можно отдохнуть и поспать."
    else:
        msg = ("Команды: look, status, move up|down|left|right [n], goto <объект>, interact <объект>, go (дверь между комнатами), "
               "sleep, wake, sew, mood <настроение>, weather <погода>, journal [текст], leave, enter.")
    save(s)
    print(status(s))
    if msg:
        print(msg)
    print()
    print(render(s))
    if s["where"] == "world":
        print("\nОбозначения: @ ты, # стена, W окно, P постер, M манекен, B кровать, T швейный стол, S диван, C компьютер,")
        print("R ковёр, F растение, K шкаф, H столик, V вид с балкона, D дверь наружу (ноутбук), G дверь между комнатами.")
        print("Рядом: " + (", ".join(near(s)) or "ничего"))


if __name__ == "__main__":
    main(sys.argv)
