\
#!/bin/sh
set -eu
cd "$(dirname "$0")"

BIN="${KUNI_BIN:-./build-alpine/bin/kuni}"
if [ ! -x "$BIN" ]; then
  echo "Executable not found: $BIN" >&2
  echo "Build first: ./build_alpine_lowmem.sh" >&2
  exit 1
fi

# Reduce allocator arena overhead and avoid core dumps on a constrained host.
ulimit -c 0 || true
export MALLOC_ARENA_MAX="${MALLOC_ARENA_MAX:-2}"
export OMP_NUM_THREADS="${OMP_NUM_THREADS:-1}"
export OPENBLAS_NUM_THREADS="${OPENBLAS_NUM_THREADS:-1}"
export VECLIB_MAXIMUM_THREADS="${VECLIB_MAXIMUM_THREADS:-1}"

exec "$BIN" "$@"
