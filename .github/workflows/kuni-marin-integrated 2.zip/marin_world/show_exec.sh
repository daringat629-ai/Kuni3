#!/bin/bash
# Показать, какие команды Марин запускала через shell (последние 50).
grep -h "EXEC:" "$HOME/kuni/logs/"* 2>/dev/null | tail -50
